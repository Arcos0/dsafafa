cd Dirección del repositorio local
git add .
git commit -m 'commit de la guia'
git remote add origin https://github.com/repositorio
git push --force origin master